-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: mib
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_actions_log`
--

DROP TABLE IF EXISTS `admin_actions_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_actions_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `description` varchar(255) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `request_type` varchar(10) NOT NULL,
  `data` blob,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `admin_actions_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_actions_log`
--

LOCK TABLES `admin_actions_log` WRITE;
/*!40000 ALTER TABLE `admin_actions_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_actions_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `street_1` varchar(255) DEFAULT NULL,
  `street_2` varchar(255) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `county` varchar(100) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `country_code` varchar(3) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `company_number` varchar(10) DEFAULT NULL,
  `phone_number` varchar(60) DEFAULT NULL,
  `is_payroll` int(1) DEFAULT '0',
  `payroll_reconciliation_type` varchar(20) DEFAULT NULL,
  `is_supporter` int(1) DEFAULT '0',
  `is_patron` int(1) DEFAULT '0',
  `notes` blob,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `draw_entrant`
--

DROP TABLE IF EXISTS `draw_entrant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draw_entrant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `street_1` varchar(255) NOT NULL,
  `street_2` varchar(255) DEFAULT NULL,
  `town` varchar(100) NOT NULL,
  `county` varchar(100) DEFAULT NULL,
  `country_code` varchar(3) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(100) DEFAULT NULL,
  `is_form_copied_and_sent_to_business` int(1) NOT NULL DEFAULT '0',
  `is_draw_numbers_sent_to_entrant` int(1) NOT NULL DEFAULT '0',
  `notes` blob,
  `payroll_reference` varchar(255) DEFAULT NULL,
  `payment_frequency` varchar(100) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `balance` float NOT NULL DEFAULT '0',
  `is_added_to_crm` int(1) NOT NULL DEFAULT '0',
  `is_consent_given_to_contact_line_manager` int(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `draw_entrant_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2038 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `draw_entrant_form`
--

DROP TABLE IF EXISTS `draw_entrant_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draw_entrant_form` (
  `form_id` int(11) NOT NULL,
  `entrant_id` int(11) NOT NULL,
  `date_sent` datetime DEFAULT NULL,
  `date_received` datetime DEFAULT NULL,
  `date_copy_returned` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`form_id`,`entrant_id`),
  KEY `entrant_id` (`entrant_id`),
  CONSTRAINT `draw_entrant_form_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `draw_entrant` (`id`),
  CONSTRAINT `draw_entrant_form_ibfk_2` FOREIGN KEY (`entrant_id`) REFERENCES `draw_entrant` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draw_entrant_form`
--

LOCK TABLES `draw_entrant_form` WRITE;
/*!40000 ALTER TABLE `draw_entrant_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `draw_entrant_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `draw_entries`
--

DROP TABLE IF EXISTS `draw_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draw_entries` (
  `entry_number` int(11) NOT NULL AUTO_INCREMENT,
  `entrant_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`entry_number`),
  KEY `entrant_id` (`entrant_id`),
  CONSTRAINT `draw_entries_ibfk_1` FOREIGN KEY (`entrant_id`) REFERENCES `draw_entrant` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21750 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `draw_form`
--

DROP TABLE IF EXISTS `draw_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `draw_form` (
  `form_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `draw_form`
--

LOCK TABLES `draw_form` WRITE;
/*!40000 ALTER TABLE `draw_form` DISABLE KEYS */;
INSERT INTO `draw_form` VALUES (1,'Direct Debit','2020-05-08 06:06:52','2020-05-08 06:06:52'),(2,'Standing Order','2020-05-08 06:06:52','2020-05-08 06:06:52'),(3,'Payroll','2020-05-08 06:06:52','2020-05-08 06:06:52');
/*!40000 ALTER TABLE `draw_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_number` varchar(100) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'Bury Times','Reporter Name','editor@burytimes.co.uk','01617001234','2020-05-21 07:58:41','2020-05-21 07:58:41');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_history`
--

DROP TABLE IF EXISTS `payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_history` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `document_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `document_id` (`document_id`),
  CONSTRAINT `payment_history_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `uploaded_documents` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=916 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `role_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'admin_actions_log:delete',1,'2020-05-08 05:53:50','2020-05-08 05:53:50'),(2,'admin_actions_log:read',1,'2020-05-08 05:53:51','2020-05-08 05:53:51'),(3,'admin_actions_log:update',1,'2020-05-08 05:53:51','2020-05-08 05:53:51'),(4,'company:create',1,'2020-05-08 05:53:51','2020-05-08 05:53:51'),(5,'company:delete',1,'2020-05-08 05:53:52','2020-05-08 05:53:52'),(6,'company:read',1,'2020-05-08 05:53:52','2020-05-08 05:53:52'),(7,'company:update',1,'2020-05-08 05:53:53','2020-05-08 05:53:53'),(8,'draw_entrant_form:create',1,'2020-05-08 05:53:53','2020-05-08 05:53:53'),(9,'draw_entrant_form:delete',1,'2020-05-08 05:53:54','2020-05-08 05:53:54'),(10,'draw_entrant_form:read',1,'2020-05-08 05:53:54','2020-05-08 05:53:54'),(11,'draw_entrant_form:update',1,'2020-05-08 05:53:55','2020-05-08 05:53:55'),(12,'draw_entrants:create',1,'2020-05-08 05:53:55','2020-05-08 05:53:55'),(13,'draw_entrants:delete',1,'2020-05-08 05:53:56','2020-05-08 05:53:56'),(14,'draw_entrants:read',1,'2020-05-08 05:53:56','2020-05-08 05:53:56'),(15,'draw_entrants:update',1,'2020-05-08 05:53:57','2020-05-08 05:53:57'),(16,'draw_entries:create',1,'2020-05-08 05:53:57','2020-05-08 05:53:57'),(17,'draw_entries:delete',1,'2020-05-08 05:53:58','2020-05-08 05:53:58'),(18,'draw_entries:read',1,'2020-05-08 05:53:58','2020-05-08 05:53:58'),(19,'draw_entries:update',1,'2020-05-08 05:53:58','2020-05-08 05:53:58'),(20,'draw_form:create',1,'2020-05-08 05:53:59','2020-05-08 05:53:59'),(21,'draw_form:delete',1,'2020-05-08 05:53:59','2020-05-08 05:53:59'),(22,'draw_form:read',1,'2020-05-08 05:54:00','2020-05-08 05:54:00'),(23,'draw_form:update',1,'2020-05-08 05:54:00','2020-05-08 05:54:00'),(24,'media:create',1,'2020-05-08 05:54:01','2020-05-08 05:54:01'),(25,'media:delete',1,'2020-05-08 05:54:01','2020-05-08 05:54:01'),(26,'media:read',1,'2020-05-08 05:54:02','2020-05-08 05:54:02'),(27,'media:update',1,'2020-05-08 05:54:02','2020-05-08 05:54:02'),(28,'payment_history:create',1,'2020-05-08 05:54:02','2020-05-08 05:54:02'),(29,'payment_history:delete',1,'2020-05-08 05:54:03','2020-05-08 05:54:03'),(30,'payment_history:read',1,'2020-05-08 05:54:03','2020-05-08 05:54:03'),(31,'payment_history:update',1,'2020-05-08 05:54:04','2020-05-08 05:54:04'),(32,'permissions:create',1,'2020-05-08 05:54:04','2020-05-08 05:54:04'),(33,'permissions:delete',1,'2020-05-08 05:54:05','2020-05-08 05:54:05'),(34,'permissions:get',1,'2020-05-08 05:54:05','2020-05-08 05:54:05'),(35,'permissions:list',1,'2020-05-08 05:54:05','2020-05-08 05:54:05'),(36,'permissions:update',1,'2020-05-08 05:54:06','2020-05-08 05:54:06'),(37,'reconciliation:create',1,'2020-05-08 05:54:06','2020-05-08 05:54:06'),(38,'reconciliation:delete',1,'2020-05-08 05:54:07','2020-05-08 05:54:07'),(39,'reconciliation:get',1,'2020-05-08 05:54:07','2020-05-08 05:54:07'),(40,'reconciliation:list',1,'2020-05-08 05:54:08','2020-05-08 05:54:08'),(41,'reconciliation:update',1,'2020-05-08 05:54:08','2020-05-08 05:54:08'),(42,'roles:create',1,'2020-05-08 05:54:08','2020-05-08 05:54:08'),(43,'roles:delete',1,'2020-05-08 05:54:09','2020-05-08 05:54:09'),(44,'roles:list',1,'2020-05-08 05:54:09','2020-05-08 05:54:09'),(45,'roles:read',1,'2020-05-08 05:54:10','2020-05-08 05:54:10'),(46,'roles:update',1,'2020-05-08 05:54:10','2020-05-08 05:54:10'),(47,'uploaded_documents:create',1,'2020-05-08 05:54:11','2020-05-08 05:54:11'),(48,'uploaded_documents:delete',1,'2020-05-08 05:54:11','2020-05-08 05:54:11'),(49,'uploaded_documents:get',1,'2020-05-08 05:54:12','2020-05-08 05:54:12'),(50,'uploaded_documents:list',1,'2020-05-08 05:54:12','2020-05-08 05:54:12'),(51,'uploaded_documents:update',1,'2020-05-08 05:54:12','2020-05-08 05:54:12'),(52,'users:create',1,'2020-05-08 05:54:13','2020-05-08 05:54:13'),(53,'users:delete',1,'2020-05-08 05:54:13','2020-05-08 05:54:13'),(54,'users:read',1,'2020-05-08 05:54:14','2020-05-08 05:54:14'),(55,'users:update',1,'2020-05-08 05:54:14','2020-05-08 05:54:14'),(56,'weekly_draw:create',1,'2020-05-08 05:54:15','2020-05-08 05:54:15'),(57,'weekly_draw:delete',1,'2020-05-08 05:54:15','2020-05-08 05:54:15'),(58,'weekly_draw:read',1,'2020-05-08 05:54:15','2020-05-08 05:54:15'),(59,'weekly_draw:update',1,'2020-05-08 05:54:16','2020-05-08 05:54:16'),(60,'weekly_draw_entries:create',1,'2020-05-08 05:54:16','2020-05-08 05:54:16'),(61,'weekly_draw_entries:delete',1,'2020-05-08 05:54:17','2020-05-08 05:54:17'),(62,'weekly_draw_entries:read',1,'2020-05-08 05:54:17','2020-05-08 05:54:17'),(63,'weekly_draw_entries:update',1,'2020-05-08 05:54:18','2020-05-08 05:54:18'),(64,'weekly_draw_media:create',1,'2020-05-08 05:54:18','2020-05-08 05:54:18'),(65,'weekly_draw_media:delete',1,'2020-05-08 05:54:19','2020-05-08 05:54:19'),(66,'weekly_draw_media:read',1,'2020-05-08 05:54:19','2020-05-08 05:54:19'),(67,'weekly_draw_media:update',1,'2020-05-08 05:54:19','2020-05-08 05:54:19'),(68,'draw_entrants:read',2,'2020-05-08 08:26:57','2020-05-08 08:26:57'),(69,'draw_forms:read',2,'2020-05-08 08:27:05','2020-05-08 08:27:05'),(70,'draw_form:read',2,'2020-05-08 08:27:11','2020-05-08 08:27:11'),(71,'users:read',2,'2020-05-08 08:27:26','2020-05-08 08:27:26'),(72,'master_view:read',1,'2020-05-26 10:59:30','2020-05-26 10:59:30'),(73,'import:bank-statement',1,'2020-06-02 05:37:06','2020-06-02 05:37:06'),(74,'import:payroll-report',1,'2020-06-02 05:37:12','2020-06-02 05:37:12');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reconciliation`
--

DROP TABLE IF EXISTS `reconciliation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reconciliation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `draw_entrant_id` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `draw_entrant_id` (`draw_entrant_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `reconciliation_ibfk_1` FOREIGN KEY (`draw_entrant_id`) REFERENCES `draw_entrant` (`id`),
  CONSTRAINT `reconciliation_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reconciliation`
--

LOCK TABLES `reconciliation` WRITE;
/*!40000 ALTER TABLE `reconciliation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reconciliation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrator','2020-05-08 05:52:23','2020-05-08 05:52:23'),(2,'Office','2020-05-08 08:25:43','2020-05-08 08:25:43'),(3,'My New Role','2020-05-27 17:42:58','2020-05-27 17:42:58');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `code` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  `settings` blob,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`code`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploaded_documents`
--

DROP TABLE IF EXISTS `uploaded_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploaded_documents` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `path_to_file` varchar(255) NOT NULL,
  `engine_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `weekly_draw`
--

DROP TABLE IF EXISTS `weekly_draw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weekly_draw` (
  `draw_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `winning_entry_id` int(11) DEFAULT NULL,
  `website_position_number` int(11) DEFAULT NULL,
  `is_blog_added_to_website` int(1) NOT NULL DEFAULT '0',
  `is_video_on_youtube` int(1) NOT NULL DEFAULT '0',
  `is_social_media_posted` int(1) NOT NULL DEFAULT '0',
  `is_prize_money_paid` int(1) NOT NULL DEFAULT '0',
  `is_mailshot_sent` int(1) NOT NULL DEFAULT '0',
  `is_consent_signed_for_photo_and_video` int(1) NOT NULL DEFAULT '0',
  `is_added_to_instagram` int(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`draw_id`),
  KEY `winning_entry_id` (`winning_entry_id`),
  CONSTRAINT `weekly_draw_ibfk_1` FOREIGN KEY (`winning_entry_id`) REFERENCES `draw_entries` (`entry_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly_draw`
--

LOCK TABLES `weekly_draw` WRITE;
/*!40000 ALTER TABLE `weekly_draw` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekly_draw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekly_draw_entries`
--

DROP TABLE IF EXISTS `weekly_draw_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weekly_draw_entries` (
  `entry_id` int(11) NOT NULL,
  `draw_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `payment_id` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`entry_id`,`draw_id`),
  KEY `draw_id` (`draw_id`),
  CONSTRAINT `weekly_draw_entries_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `draw_entries` (`entry_number`),
  CONSTRAINT `weekly_draw_entries_ibfk_2` FOREIGN KEY (`draw_id`) REFERENCES `weekly_draw` (`draw_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly_draw_entries`
--

LOCK TABLES `weekly_draw_entries` WRITE;
/*!40000 ALTER TABLE `weekly_draw_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekly_draw_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weekly_draw_media`
--

DROP TABLE IF EXISTS `weekly_draw_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weekly_draw_media` (
  `media_id` int(11) NOT NULL,
  `draw_id` int(11) NOT NULL,
  `date_sent` date DEFAULT NULL,
  `date_published` date DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`media_id`,`draw_id`),
  KEY `draw_id` (`draw_id`),
  CONSTRAINT `weekly_draw_media_ibfk_1` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`),
  CONSTRAINT `weekly_draw_media_ibfk_2` FOREIGN KEY (`draw_id`) REFERENCES `weekly_draw` (`draw_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly_draw_media`
--

LOCK TABLES `weekly_draw_media` WRITE;
/*!40000 ALTER TABLE `weekly_draw_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `weekly_draw_media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-18  9:09:58
